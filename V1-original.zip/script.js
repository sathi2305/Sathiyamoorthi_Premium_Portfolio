const glow=document.querySelector('.cursor-glow');
window.addEventListener('pointermove',e=>{glow.style.left=e.clientX+'px';glow.style.top=e.clientY+'px';});
const io=new IntersectionObserver(entries=>entries.forEach(e=>{if(e.isIntersecting)e.target.classList.add('in') }),{threshold:.12});
document.querySelectorAll('.project,.arsenal-grid>div,.credential,.timeline-item,.mini-grid a,.arch-main').forEach(x=>{x.classList.add('reveal');io.observe(x)});
