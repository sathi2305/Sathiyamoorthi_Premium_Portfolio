# Sathiyamoorthi S — Premium Portfolio

Static responsive portfolio inspired by the uploaded reference video, using the user's supplied resume and GitHub projects.

## Run
Open `index.html` directly, or serve the folder with any static server.

## Deploy
Upload the folder to Vercel, Netlify, GitHub Pages, or any static hosting provider.

## Customize
- Replace project visuals with real screenshots/video previews.
- Add verified live-demo URLs where available.
- Add a real PDF resume if desired.
- Connect the contact form/email workflow later.
